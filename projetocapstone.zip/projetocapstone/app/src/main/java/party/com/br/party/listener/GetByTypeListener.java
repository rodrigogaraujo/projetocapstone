package party.com.br.party.listener;

/**
 * Created by Isabelly on 02/05/2018.
 */

public interface GetByTypeListener<T> {
    void getByType(T t);
}
